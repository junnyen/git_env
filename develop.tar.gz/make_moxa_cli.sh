#!/bin/sh
#if [ "$1" -eq 1 ]; then

make app_moxa_cli_deb #CCACHE=1
