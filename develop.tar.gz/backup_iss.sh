#!/bin/bash
sudo cp ./out_deb/app-moxa-iss-10-1-0_10.1.0.1+1.0.0_armhf.deb /media/sf_inner_share
