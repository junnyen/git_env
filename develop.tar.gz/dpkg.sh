#/bin/bash
dpkg-i libcpss_4.1.2016.6+1.0.0_armhf.deb
dpkg --add-architecture armhf
dpkg-i libcpss_4.1.2016.6+1.0.0_armhf.deb
dpkg-i lib-moxa-io_1.0.0_armhf.deb
dpkg-i lib-moxa-eeprom-def_1.0.0_armhf.deb
dpkg-i lib-moxa-product-def_1.0.0_armhf.deb
dpkg-i lib-moxa-portmap_1.0.0_armhf.deb
dpkg-i lib-moxa-mrvl-phy-mgmt_1.0.0_armhf.deb
dpkg-i libmad_3.8.0+1.0.0_armhf.deb
dpkg-i lib-moxa-port-type-def_1.0.0_armhf.deb

