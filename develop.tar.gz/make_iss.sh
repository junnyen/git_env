#!/bin/sh
#if [ "$1" -eq 1 ]; then

make app_moxa_iss_10_1_0_deb #CCACHE=1
