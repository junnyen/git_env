#/bin/bash
export PATH="/usr/local/arm-linux-gnueabihf-6.3/usr/bin:$PATH"
export CROSS_COMPILE=arm-linux-gnueabihf-
export CC=${CROSS_COMPILE}gcc
export AS=${CROSS_COMPILE}as
export LD=${CROSS_COMPILE}ld
export CPP="${CC} -E"
export AR=${CROSS_COMPILE}ar
export STRIP=${CROSS_COMPILE}strip

cd app_moxa_iss_10_1_0

DEB_CFLAGS_SET=${CFLAGS} \
DEB_LDFLAGS_SET=${LDFLAGS} \
DEB_BUILD_OPTIONS=nocheck dpkg-buildpackage -us -uc -b -aarmhf

