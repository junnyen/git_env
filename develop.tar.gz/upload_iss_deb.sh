#!/bin/sh

if [ -n "$1" ]; then
    echo "Upload deb to $1"
    echo "----------------"
    SW_IP="$1"
else 
    SW_IP="12.0.0.100"
fi

#OUTPUT_DEB="./output/EDS/latest/package"
OUTPUT_DEB="./out_deb"
ISS_DEB0="app-moxa-iss-10-1-0_10.1.0.0+1.0.0_armhf.deb"
ISS_DEB1="app-moxa-iss-10-1-0_10.1.0.1+1.0.0_armhf.deb"
#CPSS_DEB="/home/moxa/ddk-utility-10.1.0/download/PONCAT3/PONCAT3/develop/source/package/libcpss_4.1.2016.6+1.0.0_armhf.deb"
#PORTMAP="/home/moxa/ddk-utility-10.1.0/download/PONCAT3/PONCAT3/develop/source/package/lib-moxa-portmap_1.0.0_armhf.deb"
#PHY="/home/moxa/ddk-utility-10.1.0/download/PONCAT3/PONCAT3/develop/source/package/lib-moxa-mrvl-phy-mgmt_1.0.0_armhf.deb"
if [ -d "${OUTPUT_DEB}" ]; then
    ls -t  ${OUTPUT_DEB}/${ISS_DEB1}
    scp ${OUTPUT_DEB}/${ISS_DEB1} moxa@${SW_IP}:/tmp/
else 
    echo "${OUTPUT_DEB} not found."
fi
