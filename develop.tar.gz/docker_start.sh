#/bin/bash
docker ps -a
docker start 47da && docker attach 47da
