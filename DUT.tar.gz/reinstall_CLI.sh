#!/bin/bash
sudo dpkg -i /tmp/app-moxa-cli_0.9.8_armhf.deb
