#!/bin/bash
sudo dpkg -i /tmp/app-moxa-iss-10-1-0_10.1.0.1+1.0.0_armhf.deb
